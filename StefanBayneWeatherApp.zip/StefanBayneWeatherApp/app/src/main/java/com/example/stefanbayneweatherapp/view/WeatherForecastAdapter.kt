package com.example.stefanbayneweatherapp.view

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.stefanbayneweatherapp.databinding.DisplayWeatherInfoBinding
import com.example.stefanbayneweatherapp.model.ListForWeather

// Adapter for the recycler view to show the information from the display info fragment..
class WeatherForecastAdapter (
    private val weatherList: MutableList<ListForWeather> = mutableListOf(),
    private val openDetails: (ListForWeather) -> Unit
): RecyclerView.Adapter<WeatherForecastAdapter.WeatherViewModel>() {

    inner class WeatherViewModel(
        private val binding: DisplayWeatherInfoBinding
    ): RecyclerView.ViewHolder(binding.root) {
        fun bind(weatherDetails: ListForWeather) {

            binding.tvDisplayTemperature.text = weatherDetails.weather.get(index = 0)

            binding.root.setOnClickListener{
                openDetails(weatherDetails)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        WeatherViewModel(
        DisplayWeatherInfoBinding.inflate( LayoutInflater.from(parent.context),
        parent, false )
        )

    override fun onBindViewHolder(holder: WeatherViewModel, position: Int) {
        holder.bind(weatherList[position])
    }

    override fun getItemCount() = weatherList.size
}